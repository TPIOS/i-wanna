游戏名 Game Name：Jushi Needle 2022
作者 Creator：小居士 Jushi
引擎 Engine：IWBT Studio Engine YoYoYo Edition v1_51

共15面跳刺。
摸了许久，赶在年底，发布第三年的个人年份跳刺。

测试员 Testors：
特特

再次感谢梦姐姐画的头像~

整体而言可能并没有去年做的那么好，今年也是百忙之中做的，具体牢骚在专栏中已经发完了就不再赘述了。

BGM list:
Imagine Pleasure - 星名優子
绮雪胧月 ~Eternal Fullmoon (Ibiza Remix) - Rolling Contact
春よ、来い（和楽器ver.）- AUN J-CLASSIC ORCHESTRA
SOUVENIR - BUMP OF CHICKEN