游戏名 Game Name：Jushi Needle 2024
作者 Creator：小居士 Jushi
引擎 Engine：IWBT Studio Engine YoYoYo Edition v1_51

共15面跳刺
发布第五年的个人年份跳刺（生肖跳刺系列）。

测试员 Testors：
特特

感谢万能的特特跟我一起当DDL人

鸽子就是iwanna人传统

今年原本打算准时发表的，但是感觉要削的地方真的有很多，所以就很认真的削了并堵了近路。

感谢鹤小姐的供图以及像素画~

BGM list:
Title: Halo, Paul Lipson, Lennie Moore - Impart
Stage 01: YiYi - Call of silence
Stage 02: 3R2 - Winter (Deemo Ver. Extended)
Stage 03: Kyle Gabler - Jelly
Ending: 芳賀敬太 - 星屑盤上冥路：アステロ・アキハバラ