Game Name: Happy Birthday to Zeroyume
Game Engine: IWBT Studio Engine YoYoYo Edition v1.51

This is a birthday gift for Zeroyume, released on 03.24.2021.

Creators: Jushi, cloakman, Chance, Summer, wifie, SilentNight, loli_qc

Artists: 涟鹊蓝，优空，猫猫，谢识眉

BGM List：
封面 (Cover)：幻華楽 - 少女綺想曲 ~Dream Battle
结尾 (Ending)：凛 - Muenzuka set 01 ～ 春色小径
大厅 (Hub)：漂流
夏天关 (Summer)：Alexandrite
歪覅关 (wifie)：云村的烟花
三鲜关 (cloakman)：Freeze Over
居士关 (Jushi)：Deemo title song
机遇关 (Chance)：YOASOBI-夜に駆ける【8-bit】
千愁关 (loli_qc)：Hold You In The Rain
静夜关 (SilentNight)：葵时雨