游戏名：Happy Birthday to Zeroyume
主催：小居士，机遇
作者：小居士，机遇，夏天，wifie，静夜，某三鲜，纵身一跳解千愁
技术：某三鲜，小居士
技术监督：机遇
测试：塞德莎
引擎：IWBT Studio Engine YoYoYo Edition v1.51

美工部分：
封面贺图：涟鹊蓝
结尾贺图：优空
游戏icon：猫猫
夏天关卡贴图：谢识眉

BGM：
封面：幻華楽 - 少女綺想曲 ~Dream Battle
结尾：凛 - Muenzuka set 01 ～ 春色小径
大厅：漂流
夏天关：Alexandrite
歪覅关：云村的烟花
三鲜关：Freeze Over
居士关：Deemo title song
机遇关：YOASOBI-夜に駆ける【8-bit】
千愁关：Hold You In The Rain
静夜关：葵时雨

祝零梦新的一岁，天天开心！