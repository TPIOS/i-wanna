﻿游戏名：Jushi Happy 2020 Needle
作者：望村小居士

Engine：I Wanna Be The GM8 Engine YoYoYo Edition v1.52
特别感谢：
	封面帮助：零梦丶
	技术支持：静夜、奏律、Ear

测试员：

芥子咸鱼：好难啊（
L无间C：有些刺看起来稍微有点密，白给近路封一下；Death: 579, Time: 49min18s
齊藤杏树：极限跳有点多（费解、按得手痛），新素材Get；Death: 523, Time: 51min01s
千千千手：我日，好多极限跳，建议松弛有度；Death: 570, Time: 38min23s

-----
个人第二作，15面32px，新年快乐！
做的其实确实不美观，还在学习！

-----
BGM List:
Active Planets - Harvest Carol -穢翼のユースティア BGM Medley-
Active Planets - Sweet Bite -FORTUNE ARTERIAL BGM Medley-
Active Planets - 月夜に舞う恋の花- Piano Instrumental-
Active Planets - 親愛なる世界へ -Acoustic-