Game Name：i wanna play with Mr. Zombie
Creators：Jushi，Zeroyume，ZZR，RedCrown，yolomany，Qinchui，ebb174，loli_qc，sol，Wujian，Piao
Testors: SAIRA, Tete, Flames, Cloakman, Oaildlo, sandcu, and all the creators
Coders: Jushi, Cloakman, Huafa, IWD, ZZR, Piao, Ear.1, tw

Main leader/Stage Integration: Jushi
Artists: Zeroyume, Cat


This is the fourth year of the Halloween collaboration fangame. It combines gimmick, a simple needle rush and a little hard avoidance in the end. I hope everyone could enjoy it~