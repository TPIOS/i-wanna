﻿Based on https://github.com/ThoNohT/NohBoard
A simple keyboard visualizer for i wanna player, containing arrows, Z, shift, r and S.

I am thinking whether including mouse click or not, but seldom needle games will contain interaction with mouse click. So I just omit it.