游戏名 Game Name：Jushi Needle 2021
作者 Creator：小居士 Jushi
引擎 Engine：IWBT Studio Engine YoYoYo Edition v1_51

共15面跳刺，前5面32px，中间5面16px，最后5面4px。
摸了许久，终于坚持了第二年发布个人的年份跳刺。

From 32px to 16px, then to 4px. 15 rooms in total.

测试员 Testors：
烈焰 Flames，Death: 474, Time: 0:34:15.
千愁 loli_qc, Death: 564, Time: 0:53:11.
伊尔 Ear.1, Death: 1200, Time: 1:30:00.

测试员掏的刺已经削弱，难度预估50+。

感谢零梦姐姐百忙之中拉的渐变色封面。感谢优空画的居娘（游戏icon）！
Artists: Zeroyume for Title background, Youkong for game icon.

BGM list:
Radioactive - William Joseph
空港 - 绘师岸田
Weekend - Dirk Reichardt
Piano Beat - BeaTsGOy
Cracks Invisible (佚痕) - 喵步小雨中
桃花染に咲いて (Piano Instrumental ver.) - 中恵光城