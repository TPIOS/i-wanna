Game: i wanna see the Polaris
Author: Jushi (望村小居士)

Game Tester: 张忠荣
Game Cover Producer: 零梦丶(zeroyume)

This game aims to celebrate my first work studio succeed in the first year.
Thanks to all my colleagues.