﻿Game: i wanna see the Polaris
Author: Jushi (望村小居士)

Game Tester: 张忠荣
Game Cover Producer: 零梦丶(zeroyume)

This game primarily aims to celebrate my first work studio success in the first year.
Thanks to all my colleagues.

version 2.0 updated information:
1. Fix some short cuts
2. Add one big extra stage at last (not very hard).

Please enjoy it~

version 1.5 updated information:
1. Fix some short cuts
2. Change save mode to SAVE_PRESS-'S'