游戏名 Game Name：Jushi Needle 2023
作者 Creator：小居士 Jushi
引擎 Engine：IWBT Studio Engine YoYoYo Edition v1_51

共13面跳刺
摸了许久，赶在年底，发布第四年的个人年份跳刺（生肖跳刺系列）。

测试员 Testors：
特特

感谢万能的特特跟我一起当DDL人

感谢鹤小姐的供图以及像素画~

今年也是DDL选手。

前五面使用了AI帮助生成一些东西，这是时代潮流，所以尝试做第一个吃螃蟹的人。

BGM list:
オクラホマミキサー - フォークダンス
EDGE - Cre-sc3NT
Red Carpet Extend-o-matic - Kyle Gabler
And I love you so - Don McLean