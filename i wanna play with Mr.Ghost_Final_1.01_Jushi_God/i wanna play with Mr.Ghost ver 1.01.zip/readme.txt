﻿作品名：I wanna play with Mr. Ghost

作者（共同开发）：
零梦（zeroyume）
望村小居士（Jushi）
张忠荣
小奏律（Xiaozoulv，Koyuyu）
Q少（sunlaoqq）
龙葬心宇（包子）
IWD

测试员：
千千千手（Qs）
塞德莎

封面与贴图：
零梦丶（zeroyume）
谢识眉（may）

今年是第二次万圣节合作了 希望能把这个系列做下去 今年依旧很咕 但是很开心能做完这个游戏
比去年多添加了几位制作者 希望这个游戏能带给玩家一些快乐 那么请愉快的游玩 顺便期待一下 明年的万圣节合作吧~ 

（有兴趣可以联系这几位作者哦~）

BGM List：
歌うカボチャ城の冒険:マップテーマ
The Halloween
The Halloween Puzzle
Castlevania Theme Song Series
BanG Dream Halloween Theme
IV
Lights&Motion
Ghouls
necropolis towns 2
百鬼夜行